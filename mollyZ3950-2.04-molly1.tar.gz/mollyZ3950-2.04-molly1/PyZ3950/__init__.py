"""Python Z3950/MARC/ASN.1 package, supporting ZOOM API.
"""

__all__ = ['zoom', 'zmarc']
# only pieces most users need: if you need asn1, import it explicitly
